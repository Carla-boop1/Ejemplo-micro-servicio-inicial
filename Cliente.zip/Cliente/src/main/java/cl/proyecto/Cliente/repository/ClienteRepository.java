package cl.proyecto.Cliente.repository;

import cl.proyecto.Cliente.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}
