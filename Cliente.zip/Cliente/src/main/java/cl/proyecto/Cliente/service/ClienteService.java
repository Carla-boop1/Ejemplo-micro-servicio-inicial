package cl.proyecto.Cliente.service;

import cl.proyecto.Cliente.DTO.ClienteRequestDTO;
import cl.proyecto.Cliente.DTO.ClienteResponseDTO;
import cl.proyecto.Cliente.model.Cliente;
import cl.proyecto.Cliente.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ClienteService {
    private final ClienteRepository clienteRepository;

    private ClienteResponseDTO mapToDTO (Cliente cliente){
        return new ClienteResponseDTO(
                cliente.getId(),
                cliente.getRut(),
                cliente.getNombre(),
                cliente.getPassword(),
                cliente.getCorreo(),
                cliente.getTelefono()
        );
    }

    /*LLAMADO DE METODOS DESDE EL REPOSITORIO
     */
    public List<ClienteResponseDTO> obtenerTodos(){
        return clienteRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public Optional<ClienteResponseDTO> obtenerPorId(Long id){
        return clienteRepository.findById(id).map(this::mapToDTO);
    }

    public ClienteResponseDTO guardarCliente(ClienteRequestDTO dto){
        Cliente cliente = new Cliente(null, dto.getRut(), dto.getNombre(), dto.getContraseña()
                , dto.getCorreo(), dto.getTelefono());
        return mapToDTO(clienteRepository.save(cliente));
    }

    public Optional<ClienteResponseDTO> actualizar(Long id, ClienteRequestDTO dto){
        return clienteRepository.findById(id)
                .map(existente -> {existente.setRut(dto.getRut());
                    existente.setNombre(dto.getNombre());
                    existente.setPassword(dto.getContraseña());
                    existente.setCorreo(dto.getCorreo());
                    existente.setTelefono(dto.getTelefono());
                    return mapToDTO(clienteRepository.save(existente));
                });
    }

    public void eliminar(Long id){clienteRepository.deleteById(id);}
}
