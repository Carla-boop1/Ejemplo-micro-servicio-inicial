package cl.proyecto.Cliente.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteRequestDTO {

    @NotBlank(message = "El rut no puede estar VACIO")
    private String rut;

    @NotBlank(message = "El nombre no puede estar VACIO")
    private String nombre;

    @NotBlank(message = "La contraseña no puede estar VACIO")
    private String Contraseña;

    @NotBlank(message = "El correo no puede estar VACIO")
    private String correo;

    @NotNull(message = "El telefono es OBLIGATORIO")
    private int telefono;
}
